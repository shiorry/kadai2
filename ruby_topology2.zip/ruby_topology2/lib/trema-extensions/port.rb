# -*- coding: utf-8 -*-
require 'trema-extensions/port/predicates'

module Trema
  #
  # Inserts monkey-patches to Trema::Port
  #
  class Port
    include TremaExtensions::Port
  end
end

### Local variables:
### mode: Ruby
### coding: utf-8-unix
### indent-tabs-mode: nil
### End:
